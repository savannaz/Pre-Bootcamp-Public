// kids height, when child is tall enough to rise rollercoaster

var childHeight = 57

function displayifChildIsAbleToRideTheRollerCoaster(childHeight) 
    if (ChildHeight > 52) 
{ 
    console.log("Get on that ride, kiddo!");
}
else
{
    console.log('Sorry kiddo. Maybe next year.');
}
